;; Set the debug option to enable a backtrace when a
;; problem occurs.
;(setq debug-on-error t)

; f-ing morons changed this so now I need to put it back.
; this allows the searching to use whitespace literally
(set-variable 'search-whitespace-regexp nil)

; this one is obvious
(set-background-color "black")
(set-foreground-color "light gray")
(set-cursor-color "gray")
;(tool-bar-mode)

;;
;; Register new file types that I use.
;;
;;(setq auto-mode-alist (cons '("\\.java$" . java-mode) auto-mode-alist))
;;(setq auto-mode-alist (cons '("\\.jhtml$" . java-mode) auto-mode-alist))
;;(setq auto-mode-alist (cons '("\\.jsp$" . java-mode) auto-mode-alist))
(setq auto-mode-alist (cons '("\\.tpl$" . sgml-mode) auto-mode-alist))
(setq shell-completion-fignore '("CVS"))

;; Fix the shell command from splitting the screen
(push (cons "\\*shell\\*" display-buffer--same-window-action) display-buffer-alist)

;; jde necessary components
;(add-to-list 'load-path (expand-file-name "/site/jde-2.2.6/lisp"))
;(add-to-list 'load-path (expand-file-name "/site/jde-2.2.7beta1/lisp"))
;(add-to-list 'load-path (expand-file-name "/site/jde-2.2.7beta2/lisp"))
;(add-to-list 'load-path (expand-file-name "/site/jde-2.2.7beta4/lisp"))
;(add-to-list 'load-path (expand-file-name "/site/jde-2.2.9beta5/lisp"))
;(add-to-list 'load-path (expand-file-name "/site/jde-2.2.8/lisp"))
;(add-to-list 'load-path (expand-file-name "/site/jde-2.2.9beta8/lisp"))

;(add-to-list 'load-path (expand-file-name "/site/semantic-1.3.3"))
;(add-to-list 'load-path (expand-file-name "/site/speedbar-0.13a"))
;(add-to-list 'load-path (expand-file-name "/site/elib-1.0"))
;(add-to-list 'load-path (expand-file-name "/site/eieio-0.15"))

;(add-to-list 'load-path (expand-file-name "/site/semantic-1.4beta12"))
;(add-to-list 'load-path (expand-file-name "/site/speedbar-0.13a"))
;(add-to-list 'load-path (expand-file-name "/site/elib-1.0"))
;(add-to-list 'load-path (expand-file-name "/site/eieio-0.16"))

;(add-to-list 'load-path (expand-file-name "/site/semantic-1.4beta13"))
;(add-to-list 'load-path (expand-file-name "/site/speedbar-0.14beta2"))
;(add-to-list 'load-path (expand-file-name "/site/elib-1.0"))
;(add-to-list 'load-path (expand-file-name "/site/eieio-0.17beta3"))

;(require 'jde)

;;; my jde extentions
;(load-file "c:/site/myjde.el")

;; Bash
;(setq shell-file-name "bash")
;(setenv "HOME" "/") 

;(setq binary-process-input t) ; only in new

;(setq w32-quote-process-args ?\")  ; new
;(setq win32-quote-process-args t)  ; old (XEmacs)

;(setenv "SHELL" shell-file-name) 
;(setq explicit-shell-file-name shell-file-name) 
(setq explicit-sh-args '("--login" "-i"))
(setq explicit-bash-args '("--login" "-i"))

;(setq shell-command-switch "-c") ; old
;(setq archive-zip-use-pkzip nil) ; old
;(setq win32-enable-italics t)    ; old (XEmacs)
;(setq w32-enable-italics t)      ; old ... proper modified
;(setq comint-process-echoes nil) ; old
;; end bash stuff

;; Want all buffers to use font-lock-mode by default
(setq global-font-lock-mode t)
(setq font-lock-mode t)

;; We want Alt-/ to preserve case
(setq dabbrev-case-fold-search nil)
(setq dabbrev-case-replace t)
;(open-dribble-file "Dribble")
;(open-termscript "Termscript")
;(setq gnu_path (expand-file-name (concat (getenv "GNU") "/../lib")))

;(set-variable (quote sc-auto-fill-region-p) nil)
;
;;; Turn off that annoying scrollbar
;;(toggle-scroll-bar -1)
;
;(setq load-path
;      (append load-path (list
;			 (concat (getenv "HOME") "/gnuemacs/lisp"))))


;;; Printer setings
(setq ps-landscape-mode 1)               ; use landscape mode
(setq ps-number-of-columns 2)            ; printing with two pages per page
(setq printer-name "//vinest/ITHP8100")  ; network printer

;;;;(setq-default case-fold-search nil)
;(if (memq system-type '(usg-unix-v dgux hpux irix))
;    (setq lpr-switches '("-d ljet4host")) (setq lpr-switches '("-h")))
;
;(setq compile-command "gmake -k")

;;;(load-library "rcs")
;
;(defvar pop-mail nil "*If t display new mail in a pop up mail buffer.
;	files listed in rmail-primary-inbox-list are watched")

;;(setq display-time-hook '(if pop-mail
;;      (let ((list rmail-primary-inbox-list)
;;	    file)
;;	(while list
;;	  (if (and (file-exists-p
;;		     (setq file (expand-file-name
;;				  (substitute-in-file-name (car list)))))
;;		   (/= 0 (nth 7 (file-attributes file)))) ;size != 0
;;	      (progn
;;		(save-excursion (rmail))
;;		(display-buffer (get-buffer "RMAIL"))
;;		(setq list nil))	; once only
;;	    (setq list (cdr list)))))))

;;(define-key ctl-x-map "\C-@" mouse-map)

(global-set-key "\C-cl" 'goto-line)
(global-set-key "\C-cd" 'dbx)
(global-set-key "\C-cD" 'jcarroll-setup-dbx)
(global-set-key "\C-cc" 'compile)
(global-set-key "\C-c." 'gid)
(global-set-key "\C-ck" 'kill-compilation)
(global-set-key "\C-c=" 'what-line)
(global-set-key "\C-cw" 'compare-windows)
(global-set-key "\e$" 'ispell-word)
(global-set-key "\e\C-]" 'query-replace-regexp)
(global-set-key "\C-x\C-^" 'shrink-window)
(global-set-key [f31] 'recenter)	; sun4 keybd
(setq make-backup-files nil)
(setq backup-inhibited t)
(setq vc-make-backup-files nil)
(setq kept-old-versions 0)
(setq kept-new-versions 0)

;;indent-tabs-mode
;;  Variable: *Indentation can insert tabs if this is non-nil.
;;  Plist: 1 property (variable-documentation)
;;(setq indent-tabs-mode nil)
;;(setq tab-stop-list (list 6 9 12 15 18 21 24 27 30 33 36 39 41 44 47 50))

;(put 'eval-expression 'disabled nil)
;(put 'narrow-to-page 'disabled nil)
;(put 'downcase-region 'disabled nil)
;(put 'narrow-to-region 'disabled nil)

;;; JDE Mode hook ... I seem to have lost it.
;(add-hook 'jde-mode-hook 'my-jde-mode-hook)

; Howards additions:
;(custom-set-faces
; '(font-lock-comment-face ((((class color) (background light)) (:foreground "light slate gray")))))

;;; default font HUGE! ... see lisp/term/w32-win.el for a list of fonts for
;;;   windows.
;(set-default-font "-*-Courier New-bold-r-*-*-22-*-*-*-c-*-iso8859-1")


;; This adds .h files to the c++ mode (instead of C mode)
;(setq auto-mode-alist (cons '("\\.h$" . c++-mode) auto-mode-alist))
(add-to-list 'auto-mode-alist '("\\.h\\'" . c++-mode))

;;;  Macro Bindings
(global-set-key '[f2] 'start-kbd-macro) ;;; Start
(global-set-key '[f3] 'end-kbd-macro)   ;;; End
(global-set-key '[f4] 'call-last-kbd-macro)  ;;; Call

(global-set-key '[f5] 'mouse-set-font) ;;; set a new default font for 
                                       ;;;  all buffers

(global-set-key '[f6] 'font-lock-mode) ;;; toggles font lock mode
                                       ;;;  in current buffer

(global-set-key '[f7] 'revert-buffer)  ;;; reload the buffer

(defun my-c-mode-hook ()
  (c-set-offset 'substatement-open '0));;; brackets should be at same indentation level as the statements they open

(add-hook 'c-mode-hook 'my-c-mode-hook)
(add-hook 'c++-mode-hook 'my-c-mode-hook)

;(put 'upcase-region 'disabled nil)
;;; out until further notice
;;;(load-file "/utils/emacs-21.1/site-lisp/my-c-mode-mods.el")
;(load-file "/utils/emacs-22.1/site-lisp/inform-mode.el")

;; Potential jsp mode load ... need to find multimode.el
;;;multi-mode
;	   (autoload 'multi-mode
;		     "multi-mode"
;		     "Allowing multiple major modes in a buffer."
;		     t)
;
;	   (defun jsp-mode () (interactive)
;	     (multi-mode 1
;			 'html-mode
;			 ;;your choice of modes for java and html
;			 ;;'("<%" java-mode)
;			 '("<%" jde-mode)
;			 '("%>" html-mode)))
;
;	   (setq auto-mode-alist
;		 (cons '("\\.jsp$" . jsp-mode)
;		 auto-mode-alist))

;(custom-set-faces)

;; This hack redefines this function so that backups will not be made.
;;  It is quite annoying to have to do this but I tried setting all
;;  of the possible variables I could find.
(require 'vc-cvs)
(defun vc-cvs-make-version-backups-p (file)
  "Return non-nil if version backups should be made for FILE."
;  (vc-cvs-stay-local-p file)
  nil
)

;;;;
;(load-file "~/.emacs.d/groovy-mode.el")
;(load-file "~/.emacs.d/groovy-electric.el")

;;; use groovy-mode when file ends in .groovy or has #!/bin/groovy at start
(autoload 'groovy-mode "groovy-mode" "Major mode for editing Groovy code." t)
(add-to-list 'auto-mode-alist '("\.groovy$" . groovy-mode))
(add-to-list 'interpreter-mode-alist '("groovy" . groovy-mode))

;;; make Groovy mode electric by default.
(add-hook 'groovy-mode-hook
          '(lambda ()
             (require 'groovy-electric)
             (groovy-electric-mode)))

(add-to-list 'auto-mode-alist '("\\.sar\\'" . archive-mode))
(add-to-list 'auto-mode-alist '("\\.ear\\'" . archive-mode))
(add-to-list 'auto-mode-alist '("\\.war\\'" . archive-mode))
(add-to-list 'auto-mode-alist '("\\.SAR\\'" . archive-mode))
(add-to-list 'auto-mode-alist '("\\.EAR\\'" . archive-mode))
(add-to-list 'auto-mode-alist '("\\.WAR\\'" . archive-mode))

(add-to-list 'auto-mode-alist '("\\.groovy$" . groovy-mode))

(setq-default indent-tabs-mode nil)
(setq split-width-threshold 9999) ; this makes the automaticl splitting of the window function more like it did in Emacs 22

;(autoload 'groovy-mode "groovy-mode" "Groovy editing mode." t)

(load-file "~/.emacs.d/markdown-mode.el")
(autoload 'markdown-mode "markdown-mode" "Major mode for editing Markdown files" t)
(add-to-list 'auto-mode-alist '("\\.markdown\\'" . markdown-mode))
;(add-to-list 'auto-mode-alist '("\\.md\\'" . markdown-mode))
(add-to-list 'auto-mode-alist '("\\.md\\'" . gfm-mode))

(autoload 'gfm-mode "markdown-mode"
   "Major mode for editing GitHub Flavored Markdown files" t)
(add-to-list 'auto-mode-alist '("README\\.md\\'" . gfm-mode))

(require 'yaml-mode)
(add-to-list 'auto-mode-alist '("\\.yml\\'" . yaml-mode))
(add-to-list 'auto-mode-alist '("\\.yaml\\'" . yaml-mode))


(custom-set-variables
 ;; custom-set-variables was added by Custom.
 ;; If you edit it by hand, you could mess it up, so be careful.
 ;; Your init file should contain only one such instance.
 ;; If there is more than one, they won't work right.
 '(js-indent-level 2)
 '(mode-require-final-newline nil))
(custom-set-faces
 ;; custom-set-faces was added by Custom.
 ;; If you edit it by hand, you could mess it up, so be careful.
 ;; Your init file should contain only one such instance.
 ;; If there is more than one, they won't work right.
 '(default ((t (:inherit nil :stipple nil :background "black" :foreground "light gray" :inverse-video nil :box nil :strike-through nil :overline nil :underline nil :slant normal :weight normal :height 120 :width normal :foundry "unknown" :family "DejaVu Sans Mono")))))
